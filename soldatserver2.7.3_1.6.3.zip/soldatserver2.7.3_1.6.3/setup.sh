#!/bin/bash

echo "# Run Server"
/soldat/soldatserver